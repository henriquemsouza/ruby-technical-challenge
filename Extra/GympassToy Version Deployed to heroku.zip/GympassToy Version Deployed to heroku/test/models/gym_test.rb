require 'test_helper'

class GymTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
