require "application_system_test_case"

class GymsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit gyms_url
  #
  #   assert_selector "h1", text: "Gym"
  # end
end
